def calcula_posicao(posicao_inicial, velocidade_inicial, aceleracao, tempo_decorrido):
    return 0
